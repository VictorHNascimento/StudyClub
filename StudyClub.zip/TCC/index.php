<?php
include 'connections/conectar.php';
session_start();

$login = '';
$senha = '';
$_SESSION['login'] = $login;	
$_SESSION['senha'] = $senha;

header('location:html/login.php');
?>