<?php

$host = "127.0.0.1:3312";
$name = "studyclub";
$user = "root";
$senha = "";

$mysqli = new mysqli($host, $user, $senha, $name);
if ($mysqli->connect_errno) {
	echo "Pane no sistema alguém me desconfigurou!";
} else{
	//echo "Conectado com sucesso, pronto para realizar as funções";
}
