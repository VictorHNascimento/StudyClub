<?php
require('conectar.php');

session_start();
$login = $_POST['login'];
$senha = $_POST['senha'];
$query = "SELECT * FROM logUser where nickUser = '$login' and senhaUser = md5('$senha')";
$verificar = mysqli_query($mysqli, $query);

if (mysqli_num_rows($verificar)>0) {
	$_SESSION['login'] = $login;
	$_SESSION['senha'] = $senha;
	$query = sprintf("SELECT nomeUser FROM caduser WHERE nickUser ='".$_SESSION['login']."' and senhaUser = md5('".$_SESSION['senha']."')");
	$listar = mysqli_query($mysqli, $query);
	$linha = mysqli_fetch_assoc($listar);
	$_SESSION['nome'] = $linha['nomeUser'];
	header('location:../html/realizar.php');
} else{
	header('location:../html/login.php?erro=dadoserrado');
}
?>