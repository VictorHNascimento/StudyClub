
<?php
session_start();
require('listar.php');
require('conectar.php');
$nome = $_POST['nome'];
$materia = $_POST['materia'];
$progresso = $_POST['progresso'];
$status = $_POST['status'];
$data = $_POST['data'];
$prazo = $_POST['prazo'];
$desc = $_POST['desc'];

$query = "CALL rotInsTarefa($id,'$nome','$materia','$progresso','$status','$data','$prazo','$desc');";

$inserir = mysqli_query($mysqli,$query);

if ($inserir) {
	header('location:../html/tarefas.php');
} else{
	header('location:../html/novo.php');
}
?>h