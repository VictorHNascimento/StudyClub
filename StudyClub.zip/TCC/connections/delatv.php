<?php
require('../connections/conectar.php');
session_start();
$idtarefa = $_GET['idTarefa'];
$query = sprintf("SELECT idUser FROM caduser WHERE nickUser ='".$_SESSION['login']."' and senhaUser = md5('".$_SESSION['senha']."')");
$buscar = mysqli_query($mysqli, $query);
$row = mysqli_fetch_assoc($buscar);
$id = $row['idUser'];
$query = sprintf("DELETE FROM cadtarefa WHERE idTarefa = $idtarefa and idUser = $id");
$deletar = mysqli_query($mysqli, $query);
if ($deletar) {
	header('location:../html/tarefas.php');
} else{
	var_dump($deletar);
}

?>