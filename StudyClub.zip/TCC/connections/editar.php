
<?php
session_start();
require('conectar.php');
$idtarefa = $_GET['idTarefa'];
$nome = $_POST['nome'];
$materia = $_POST['materia'];
$progresso = $_POST['progresso'];
$status = $_POST['status'];
$data = $_POST['data'];
$prazo = $_POST['prazo'];
$desc = $_POST['desc'];

$query = "UPDATE `cadtarefa` SET
`nomeTarefa` = '$nome',
`mateTarefa` = '$materia',
`progTarefa` = '$progresso',
`statusTarefa` = '$status',
`dataTarefa` = '$data',
`prazoTarefa` = '$prazo',
`descTarefa` = '$desc'
	WHERE `cadtarefa`.`idTarefa` =$idtarefa;";
$inserir = mysqli_query($mysqli, $query);

if ($inserir) {
	header('location:../html/tarefas.php');
} else{
	var_dump($query);
}
?>
