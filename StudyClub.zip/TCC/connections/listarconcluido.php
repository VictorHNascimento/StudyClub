<?php
require('conectar.php');
$user = $_SESSION['login'];
$senha = $_SESSION['senha'];
$query = sprintf("SELECT idUser FROM caduser WHERE nickUser ='".$_SESSION['login']."' and senhaUser = md5('".$_SESSION['senha']."')");
$buscar = mysqli_query($mysqli, $query);
$row = mysqli_fetch_assoc($buscar);
$id = $row['idUser'];
$query = sprintf("SELECT * FROM tarefaconcluida WHERE idUser = $id;");
$listar = mysqli_query($mysqli, $query);
?>

