<?php
require('conectar.php');
session_start();
$user = $_SESSION['login'];
$senha = $_SESSION['senha'];

$query = sprintf("SELECT * FROM caduser WHERE nickUser = '$user' and senhaUser = md5('$senha')");
$listar = mysqli_query($mysqli, $query);
?>