<?php
	switch (utf8_encode($linha['mateTarefa'])) {
		case "História": 
		echo "<i class='bx bx-bone'></i>";
		break;
					
		case "Geografia": 
		echo "<i class='bx bx-world'></i>";
		break;

		case "Inglês": 
		echo "<i class='bx bx-dollar-circle'></i>";
		break;

		case "Língua Portuguesa": 
		echo "<i class='bx bx-pencil'></i>";
		break;

		case "Literatura": 
		echo "<i class='bx bx-book-content'></i>";
		break;

		case "Redação": 
		echo "<i class='bx bx-clipboard'></i>";
		break;

		case "Filosofia": 
		echo "<i class='bx bx-brain'></i>";
		break;

		case "Sociologia": 
		echo "<i class='bx bx-message-rounded-error'></i>";
		break;

		case "Matemática": 
		echo "<i class='bx bx-calculator'></i>";
		break;

		case "Física": 
		echo "<i class='bx bx-run'></i>";
		break;

		case "Química": 
		echo "<i class='bx bx-vial'></i>";
		break;

		case "Educação Física": 
		echo "<i class='bx bx-basketball'></i>";
		break;

		case "Artes": 
		echo "<i class='bx bx-palette'></i>";
		break;

		case "Biologia": 
		echo "<i class='bx bx-spa'></i>";
		break;
}
?>
