
<?php
require('conectar.php');
utf8_encode($nome = $_POST['nome']);
utf8_encode($nasc = $_POST['data']);
utf8_encode($sexo = $_POST['sexo']);
utf8_encode($estado = $_POST['estado']);
utf8_encode($cidade = $_POST['cidade']);
utf8_encode($escola = $_POST['escola']);
utf8_encode($email = $_POST['email']);
utf8_encode($senha = $_POST['senha']);
utf8_encode($user = $_POST['user']);
$query = "CALL rotInsUser('$nome', '$nasc', '$sexo', '$estado', '$cidade', '$escola', '$email', '$senha', '$user')"; 
$inserir = mysqli_query($mysqli, $query);

if ($inserir) {
	header('location:../html/login.php?cadastro=cadatrado');
} else{
	header('location:../html/cadastro.php?erro=dadoserrado');
}
?>