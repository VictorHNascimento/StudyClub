<?php 

if ($_SESSION['login'] = '' || $_SESSION['senha'] = '') {
	header('location:../index.php');
}
?>