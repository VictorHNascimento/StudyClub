<html>
    <head>
        <title>Cadastro - StudyClub</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <link rel="stylesheet" href="../css/cadastro.css">
        <link rel="shortcut icon" type="imagex/png" href="../favico.ico">
    </head>
    <body>
        <section>
            <div class="color"></div>
            <div class="color"></div>
            <div class="color"></div>
            <div class="box">
                <div class="square" style="--i:0;"></div>
                <div class="square" style="--i:1;"></div>
                <div class="square" style="--i:2;"></div>
                <div class="square" style="--i:3;"></div>
                <div class="square" style="--i:4;"></div>
                <div class="container">
                    <div class="form1">
                        <h2>Faça seu Cadastro</h2>
                        <form action="../connections/cadastrar.php" method="POST">
                            <div class="tudo">
                                <?php
                        if (isset($_GET['erro']) == "dadoserrado") { echo"<p class='alert alert-danger'>Erro ao Cadastrar!</p>";
                        }
                        ?>
                                <div class="inputBox">
                                    <input type="text" name="nome" placeholder="Nome" required="">
                                </div>
                                <div class="inputBox">
                                    <input type="text" name="user" placeholder="Nome de Usuário" required="">
                                </div>
                                 <div class="inputBox">
                                    <input type="email" name="email" placeholder="Email" required="">
                                </div>
                               
                               <div class="inputBox position">
                                <img src="../img/eye.svg" class="olho">
                                    <input type="password" name="senha" placeholder="Senha" required="" class="senha">
                                </div>

                                 <div class="inputBox">
                                    <select name="sexo" class="inputBox" required>
                                        <option value="" selected="">Selecionar Gênero</option>
                                        <option value="Masculino">Masculino</option>
                                        <option value="Feminino">Feminino</option>
                                        <option value="Não informou">Prefiro não informar</option>
                                        <option value="outro">Outro</option>
                                    </select>
                                </div>

                                <div class="inputBox">
                                    <input type="date" name="data" required="">
                                </div>


                                <div class="inputBox">
                                    <input type="text" name="cidade" placeholder="Cidade" required="">
                                </div>


                                 <div class="inputBox">
                                    <input type="text" name="estado" placeholder="Estado" required="">
                                </div>
                                <div class="inputBox">
                                    <input type="text" name="escola" placeholder="Escola" required="">
                                </div>

                                <div class="inputBoxC">
                                <input type="submit" name="submit" value="Fazer Cadastro">
                            </div>
                            </div>
                            
                            <p class="forget">Já tem conta?<a href="login.php"> Faça Login</a></p>
                        </form>
                    </div>
                </div>
            </div>
        </section>

        <script>
            let container = document.querySelector('div');
            let input = document.querySelector('.senha');
            let icon = document.querySelector('img');

            icon.addEventListener('click', function(){
                container.classList.toggle('visible');
                if (container.classList.contains('visible')) {
                    icon.src = '../img/eye-off.svg';
                    input.type = 'text';
                } else{
                    icon.src = '../img/eye.svg';
                    input.type = 'password';
                }
            });
        </script>

    </body>
</html>