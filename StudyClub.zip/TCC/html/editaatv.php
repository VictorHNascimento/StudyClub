<?php
require('../connections/conectar.php');
session_start();
$idtarefa = $_GET['idTarefa'];
$query = sprintf("SELECT idUser FROM caduser WHERE nickUser ='".$_SESSION['login']."' and senhaUser = md5('".$_SESSION['senha']."')");
$buscar = mysqli_query($mysqli, $query);
$row = mysqli_fetch_assoc($buscar);
$id = $row['idUser'];
$query = sprintf("SELECT * FROM cadtarefa WHERE idUser = $id and idTarefa = $idtarefa;");
$listar = mysqli_query($mysqli, $query);
$linha = mysqli_fetch_assoc($listar);
?>
<html>
    <head>
        <title>Editar - StudyClub</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <link rel="stylesheet" href="../css/novaatv.css">
        <link rel="shortcut icon" type="imagex/png" href="../favico.ico">
    </head>
    <body>
        <section>
            <div class="color"></div>
            <div class="color"></div>
            <div class="color"></div>
            <div class="box">
                <div class="square" style="--i:0;"></div>
                <div class="square" style="--i:1;"></div>
                <div class="square" style="--i:2;"></div>
                <div class="square" style="--i:3;"></div>
                <div class="square" style="--i:4;"></div>
                <div class="container">
                    <div class="form1">
                        <h2>Editar Tarefa</h2>
                        <form action="../connections/editar.php?idTarefa=<?php echo $idtarefa;?>" method="POST" id="atividade">
                            <div class="tudo">
                                <div class="inputBox">
                                    <input type="text" name="nome" placeholder="Nome da Tarefa" required=""  value='<?php echo utf8_encode($linha["nomeTarefa"])?>'>
                                </div>
                                <div class="inputBox">
                                     <select name="materia" class="inputBox" required>
                                        <option value="<?php echo utf8_encode($linha["mateTarefa"])?>" selected=""><?php echo utf8_encode($linha["mateTarefa"])?></option>
                                        <option value="Artes">Artes</option>
                                        <option value="Biologia">Biologia</option>
                                        <option value="Educação Física">Educação Física</option>
                                        <option value="Física">Física</option>
                                        <option value="Filosofia">Filosofia</option>
                                        <option value="Geografia">Geografia</option>
                                        <option value="História">História</option>
                                        <option value="Inglês">Inglês</option>
                                        <option value="Literatura">Literatura</option>
                                        <option value="Língua Portuguesa">Língua Portuguesa</option>
                                        <option value="Matemática">Matemática</option>
                                        <option value="Química">Química</option>
                                        <option value="Redação">Redação</option>
                                        <option value="Sociologia">Sociologia</option>
                                    </select>
                                </div>
                                 <div class="inputBox">
                                    <input type="number" name="progresso" placeholder="Progesso da Tarefa(%)" required=""  value='<?php echo utf8_encode($linha["progTarefa"])?>'>
                                </div>
                               
                                 <div class="inputBox">
                                    <select name="status" class="inputBox" required>
                                        <option value="<?php echo utf8_encode($linha["statusTarefa"])?>" selected=""><?php echo utf8_encode($linha["statusTarefa"])?></option>
                                        <option value="A Realizar">A Realizar</option>
                                        <option value="Em Andamento">Em Andamento</option>
                                        <option value="Concluida">Concluída</option>
                                    </select>
                                </div>

                                <div class="inputBox">
                                    <input  type="date" name="data" required="" placeholder="Data de Ínicio" value='<?php echo utf8_encode($linha["dataTarefa"])?>'>
                                </div>


                                <div class="inputBox">
                                    <input type="date" name="prazo" required="" placeholder="Prazo Final"  value='<?php echo utf8_encode($linha["prazoTarefa"])?>'>
                                </div>

                                 <div class="inputBox">
                                    <textarea class="inputBox" name="desc" required="" form="atividade" placeholder="Descrição da Atividade"><?php echo utf8_encode($linha["descTarefa"])?></textarea>
                                </div>
                            
                                <div class="inputBoxC">
                                <input type="submit" name="submit" value="Editar">
                            </div>
                            </div>
                            <br>
                            <p class="forget"><a href="modalatvs.php"> Voltar</a></p>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </body>
</html>