<?php
session_start();
?>
<html>
    <head>
        <title>Login - StudyClub</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <link rel="stylesheet" href="../css/stylecad.css">
        <link rel="shortcut icon" type="imagex/png" href="../favico.ico">
    </head>
    <body>
        <section>
            <div class="color"></div>
            <div class="color"></div>
            <div class="color"></div>
            <div class="box">
                <div class="square" style="--i:0;"></div>
                <div class="square" style="--i:1;"></div>
                <div class="square" style="--i:2;"></div>
                <div class="square" style="--i:3;"></div>
                <div class="square" style="--i:4;"></div>
                <div class="container">
                    <div class="form">
                        <h2>Faça seu Login</h2>
                        <form action="../connections/verificaLog.php" method="POST">
                        <?php
                        if (isset($_GET['erro']) == "dadoserrado") { echo "<p class='alert alert-info'> Dados Incorretos</p>";
                            }

                        if (isset($_GET['cadastro']) == "cadastrado") { echo" <script>alert('Cadastrado com sucesso');</script>";
                    }
                        ?>
                            <div class="inputBox">
                                <input type="text" placeholder="Nick de Usuário" name="login" required="Digite seu nickname">
                            </div>
                            <div class="inputBox">
                                 <img src="../img/eye.svg" class="olho">
                                <input type="password" placeholder="Senha" name="senha" required="Digite sua senha" class="senha">
                            </div>
                            <div class="inputBox">
                                <input type="submit" value="Login">
                            </div>
                            <p class="forget">Esqueceu sua senha? Clique<a href="#"> Aqui</a></p>
                            <p class="forget">Ainda não tem conta?<a href="cadastro.php"> Cadastre-se</a></p>
                        </form>
                    </div>
                </div>
            </div>
        </section>

         <script>
            let container = document.querySelector('div');
            let input = document.querySelector('.senha');
            let icon = document.querySelector('img');

            icon.addEventListener('click', function(){
                container.classList.toggle('visible');
                if (container.classList.contains('visible')) {
                    icon.src = '../img/eye-off.svg';
                    input.type = 'text';
                } else{
                    icon.src = '../img/eye.svg';
                    input.type = 'password';
                }
            });
        </script>

    </body>
</html>
