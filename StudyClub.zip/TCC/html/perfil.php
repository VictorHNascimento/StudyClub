<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Perfil</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fint-awesome/5.15.2/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="../css/perfil.css">
	<link rel="shortcut icon" type="imagex/png" href="../favico.ico">
</head>
<body>
	<header>
		<div class="user">
			<img src="../img/anonimo.png">
			<?php require ("../connections/usuario.php");
				while($linha = mysqli_fetch_assoc($listar))
				{ 
			?>
			<h3 class="name"><?php echo utf8_encode($linha["nomeUser"]); ?></h3>
			<h2 class="post">@<?php echo utf8_encode($linha["nickUser"]); ?></h2>
			<p class="post"><?php echo utf8_encode($linha["escolaUser"]); ?></p>
			<?php } ?>
		</div>
		<nav class="navbar">
			<ul>
				<li><a href="#feed">feed</a></li>
				<li><a href="#dados">dados</a></li>
				<li><a href="#seguidores">seguidores</a></li>
				<li><a href="#fav">favoritos</a></li>
				<li><a href="#crono">organização</a></li>
			</ul>
		</nav>
	</header>
	<div class="container">
		<section class="feed" id="feed">
			<div class="share">
				<a href="#" class="facebook"></a>
				<a href="#" class="twitter"></a>
				<a href="#" class="instagram"></a>
				<a href="#" class="pinterest"></a>
				<a href="#" class="linkedin"></a>
			</div>
		</section>
	</div>
</body>
</html>