<?php 
	$idtarefa = $_GET['idTarefa'];
var_dump($idtarefa);
?>
