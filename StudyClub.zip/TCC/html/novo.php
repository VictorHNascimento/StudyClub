<?php
session_start();
require('../connections/listar.php');
?>
<html>
    <head>
        <title>Novo - StudyClub</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <link rel="stylesheet" href="../css/novaatv.css">
        <link rel="shortcut icon" type="imagex/png" href="../favico.ico">
    </head>
    <body>
        <section>
            <div class="color"></div>
            <div class="color"></div>
            <div class="color"></div>
            <div class="box">
                <div class="square" style="--i:0;"></div>
                <div class="square" style="--i:1;"></div>
                <div class="square" style="--i:2;"></div>
                <div class="square" style="--i:3;"></div>
                <div class="square" style="--i:4;"></div>
                <div class="container">
                    <div class="form1">
                        <h2>Nova Tarefa</h2>
                        <form action="../connections/novaatividade.php" method="POST" id="atividade">
                            <div class="tudo">
                                <div class="inputBox">
                                    <input type="text" name="nome" placeholder="Nome da Tarefa" required="">
                                </div>
                                <div class="inputBox">
                                     <select name="materia" class="inputBox" required>
                                        <option value="" selected="">Informe a Matéria</option>
                                        <option value="Artes">Artes</option>
                                        <option value="Biologia">Biologia</option>
                                        <option value="Educação Física">Educação Física</option>
                                        <option value="Física">Física</option>
                                        <option value="Filosofia">Filosofia</option>
                                        <option value="Geografia">Geografia</option>
                                        <option value="História">História</option>
                                        <option value="Inglês">Inglês</option>
                                        <option value="Literatura">Literatura</option>
                                        <option value="Língua Portuguesa">Língua Portuguesa</option>
                                        <option value="Matemática">Matemática</option>
                                        <option value="Química">Química</option>
                                        <option value="Redação">Redação</option>
                                        <option value="Sociologia">Sociologia</option>
                                    </select>
                                </div>
                                 <div class="inputBox">
                                    <input type="number" name="progresso" placeholder="Progesso da Tarefa(%)" required="">
                                </div>
                               
                                 <div class="inputBox">
                                    <select name="status" class="inputBox" required>
                                        <option value="" selected="">Status da Tarefa</option>
                                        <option value="A Realizar">A Realizar</option>
                                        <option value="Em Andamento">Em Andamento</option>
                                        <option value="Concluida">Concluída</option>
                                    </select>
                                </div>

                                <div class="inputBox">
                                    <input  type="text" name="data" required="" placeholder="Data de Ínicio" onfocus="(this.type='date')">
                                </div>


                                <div class="inputBox">
                                    <input type="text" name="prazo" required="" placeholder="Prazo Final" onfocus="(this.type='date')">
                                </div>

                                 <div class="inputBox">
                                    <textarea class="inputBox" name="desc" required="" form="atividade" placeholder="Descrição da Atividade"></textarea>
                                </div>
                            
                                <div class="inputBoxC">
                                <input type="submit" name="submit" value="Cadastrar">
                            </div>
                            </div>
                            <br>
                            <p class="forget"><a href="tarefas.php"> Voltar</a></p>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </body>
</html>