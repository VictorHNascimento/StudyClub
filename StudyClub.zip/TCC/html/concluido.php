<!DOCTYPE html>
<?php
session_start();
 ?>
<html>
<head>
	<title>Concluídas - StudyClub</title>
	<link rel="stylesheet" href="../css/tarefas.css">
	<link rel="stylesheet" href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css">
	<link rel="shortcut icon" type="imagex/png" href="../favico.ico">
</head>
<body>
		<nav class="sidebar">
		<div class="logo_content">
				<div class="logo">
					<div class="logo_name">StudyClub</div>
				</div>
				<i class='bx bx-menu' id="btn"></i>
			</div>
			<ul class="nav_list">
				<li>
					<i class='bx bx-search'></i>
					<input type="text" placeholder="Pesquise...">
					<span class="tooltip">Pesquisa</span>
				</li>
				<li>
					<a href="tarefas.php">
						<i class='bx bx-grid-alt'></i>
						<span class="links_name">Atividades</span>
					</a>
					<span class="tooltip">Atividades</span>
				</li>
				<li>
					<a href="#">
						<i class='bx bx-user'></i>
						<span class="links_name">Perfil</span>
					</a>
					<span class="tooltip">Perfil</span>
				</li>
				<li>
					<a href="pomodoro.php" target="_blank">
						<i class='bx bx-alarm'></i>
						<span class="links_name">Timer Pomodoro</span>
					</a>
					<span class="tooltip">Timer</span>
				</li>
				<li>
					<a href="materiais.php">
						<i class='bx bx-book-bookmark'></i>
						<span class="links_name">Materiais Didáticos</span>
					</a>
					<span class="tooltip">Materiais</span>
				</li>
				<li>
					<a href="#">
						<i class='bx bx-cog'></i>
						<span class="links_name">Configurações</span>
					</a>
					<span class="tooltip">Configurações</span>
				</li>
			</ul>
			<div class="profile_content">
				<div class="profile">
					<div class="profile_details">
						<img src="../img/anonimo.png">
						<div class="name_school">
							<div class="name"><?php echo $_SESSION['nome'];?></div>
							<div class="school"></div>
						</div>
					</div>
					<a href="../index.php"><i class='bx bx-log-out' id="log_out"></i></a>
				</div>
			</div>
	</nav>s
	<main>
		<section class="glass">
			<div class="dashboard">
				<img src="../img/anonimo.png">
				<h3><?php echo utf8_encode($_SESSION['nome']);?></h3>
				<div class="links">
					<div class="link">
						<i class='bx bx-plus'></i>
						<h2><a href="novo.php">Novo</a></h2>
					</div>
					<div class="link">
						<i class='bx bx-pencil'></i>
						<h2><a href="realizar.php">À Realizar</a></h2>
					</div>
					<div class="link">
						<i class='bx bx-history'></i>
						<h2><a href="tarefas.php">Em Andamento</a></h2>
					</div>
					<div class="link">
						<i class='bx bx-list-check'></i>
						<h2><a href="concluido.php">Terminado</a></h2>
					</div>
				</div>
			</div>
			<div class="tasks">
				<div class="status">
					<h1>Lições Concluídas</h1>
				</div>
				
				<!-- GERAR ATIVIDADE -->
				<?php require ("../connections/listarconcluido.php");
						while($linha = mysqli_fetch_assoc($listar))
				{
					$modal = $linha['idTarefa'];
				?>
					<a href="modalatvs.php?idTarefa=<?php echo $modal;?>"><div class="card">
						<?php
							include '../connections/icons.php';
						?>
					
					<div class="card-info">
						<h2><?php  echo utf8_encode($linha["mateTarefa"]);?></h2>
						<p><?php echo utf8_encode($linha["nomeTarefa"]);?></p>
					</div>
					<h2 class="percentage"><?php echo $linha["progTarefa"];?>%</h2>
				</div></a>
				<?php
				} ?>
				</div>
			</div>
		</section>
	</main>
	<div class="circle1"></div>
	<div class="circle2"></div>
	<footer>
		<div class="waves">
			<div class="wave" id="wave1"></div>
			<div class="wave" id="wave2"></div>
			<div class="wave" id="wave3"></div>
			<div class="wave" id="wave4"></div>
		</div>
		<ul class="social_icon">
			<li><a href="#"><ion-icon name="logo-twitter"></ion-icon></a></li>
			<li><a href="#"><ion-icon name="logo-instagram"></ion-icon></a></li>
		</ul>
		<ul class="menu">
			<li><a href="criadores.php" target="_blank">Criadores</a></li>
			<li><a href="#">Contato</a></li>
		</ul>
		<p>&copy2021 StudyClub | Todos os direitos reservados</p>
	</footer>
	<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
	<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
	<script>
			let btn = document.querySelector("#btn");
			let sidebar = document.querySelector(".sidebar");
			let searchBtn = document.querySelector(".bx-search");

			btn.onclick = function() {
				sidebar.classList.toggle("active");
			}
			searchBtn.onclick = function() {
				sidebar.classList.toggle("active");
			}
	</script>
</body>
</html>