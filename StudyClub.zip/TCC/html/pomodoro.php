<!DOCTYPE html>
<?php
session_start();
 ?>
<html lang="pt-br">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Pomodoro - StudyClub</title>
  <link rel="stylesheet" href="../css/pomo.css"/>
  <link rel="shortcut icon" type="imagex/png" href="../favico.ico">
</head>

<body>
  <div class="color"></div>
 <div class="color"></div>
 <div class="color"></div>
  <div class="box">
  <div id="wrapper-main">
    <h1>Inicie Seus Estudos</h1>

    <figure class="clock">
      <div class="mins">0</div>
      <div>:</div>
      <div class="secs">00</div>
      <audio src="http://soundbible.com/mp3/service-bell_daniel_simion.mp3"></audio>
      <svg class="progress-ring">
        <circle class="progress-ring__circle" stroke-width="8" fill="transparent" r="110" cx="120" cy="120" />
      </svg>
      <svg class="static-ring">
        <circle class="static-ring__circle" stroke-width="8" fill="transparent" r="110" cx="120" cy="120" />
      </svg>
      <p class="session">FOCO</p>
      <button class="start">&nbsp;</button>
      <button class="reset"><i>⟲</i> Resetar</button>
      <button class="pause">&nbsp;</button>
    </figure>

    <form action=".">
      <label for="focusTime">Tempo de Foco:</label>
      <input type="number" value="25" id="focusTime" />
      <label for="breakTime">Tempo de Pausa:</label>
      <input type="number" value="5" id="breakTime" />
      <button type="submit">Salvar</button> 
      <p>Configurações aplicadas após cada sessão. Reseta após deslogar.</p>
      <br>
      <p>Para iniciar a contagem, clique em cima do timer.</p>
    </form>

    <script src="../js/settings.js"></script>
    <script src="../js/timer.js"></script>
    <script src="../js/progress.js"></script>
  </div>
</div>
</body>
</html>

<!--
    Código Fonte por: <a href="https://www.youtube.com/channel/UC74BFCI_FbThOjUqx6gmccg" target="_blank">abhik-b</a>.
    Mod by <a href="https://github.com/tobealive" target="_blank">tobealive</a>.
  </footer> -->