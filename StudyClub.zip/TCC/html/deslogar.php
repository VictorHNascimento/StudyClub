<?php
session_start();
$_SESSION['login'] = NULL;
$_SESSION['senha'] = NULL;

header('location:../index.php');

?>