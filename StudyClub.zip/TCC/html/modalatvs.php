<!DOCTYPE html>
<?php
require('../connections/conectar.php');
session_start();
$idtarefa = $_GET['idTarefa'];
$query = sprintf("SELECT idUser FROM caduser WHERE nickUser ='".$_SESSION['login']."' and senhaUser = md5('".$_SESSION['senha']."')");
$buscar = mysqli_query($mysqli, $query);
$row = mysqli_fetch_assoc($buscar);
$id = $row['idUser'];
$query = sprintf("SELECT * FROM cadtarefa WHERE idUser = $id and idTarefa = $idtarefa;");
$listar = mysqli_query($mysqli, $query);
$linha = mysqli_fetch_assoc($listar);
?>

<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="../css/modalatvs.css">
	<link rel="shortcut icon" type="imagex/png" href="../favico.ico">
</head>
<body>
<div id="modalatv" class="modal-container mostrar">
	<div class="modal">
		<a class='fechar' href="javascript:history.back()"><p>X</p></a>
		<h2 class="titulo" style="color: white;" ><?php echo utf8_encode($linha["nomeTarefa"])?></h2>
		<h3 class="subtitulo" style="color: white;"><?php echo utf8_encode($linha["mateTarefa"])?></h3>
		<br>

			<p class="campo" style="color: white;">Data Inicial:<span class="dados" style="color: white;"><?php echo utf8_encode($linha["dataTarefa"])?></span> </p>
			<p class="campo" style="color: white;">Prazo Final:<span class="dados" style="color: white;"><?php echo utf8_encode($linha["prazoTarefa"])?></span> </p>
			<p class="campo" style="color: white;">Descrição:<span class="dados" style="color: white;"><?php echo utf8_encode($linha["descTarefa"])?></span> </p>
			<p class="campo" style="color: white;">Progresso:<span class="dados" style="color: white;"><?php echo utf8_encode($linha["progTarefa"])?>%</span> </p>
			<p class="campo" style="color: white;">Status:<span class="dados" style="color: white;"><?php echo utf8_encode($linha["statusTarefa"])?></span> </p>
			<br>
			<div class="btn">
				<a class="btn_edit" href='editaatv.php?idTarefa=<?php echo $idtarefa;?>'>Editar</a>
				<a class="btn_del" href='../connections/delatv.php?idTarefa=<?php echo $idtarefa;?>'>Deletar</a>
			</div>
	</div>
</div>
</body>
</html>